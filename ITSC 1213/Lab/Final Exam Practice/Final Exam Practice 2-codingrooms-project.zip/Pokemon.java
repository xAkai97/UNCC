public class Pokemon implements Comparable<Pokemon> {

    private String name;
    private boolean aggressive;
    private int attack;
    private int defense;

    public Pokemon(String name, boolean aggressive, int attack, int defense) {
        this.name = name;
        this.aggressive = aggressive;
        this.attack = attack;
        this.defense = defense;
    }

    public int getAttack() {
        return attack;
    }

    public int getDefense() {
        return defense;
    }

    public String getName() {
        return name;
    }

    public boolean isAggressive() {
        return aggressive;
    }

    public int compareTo(Pokemon other) {
        if (this.aggressive && !other.isAggressive())
            return 1;
        if (!this.aggressive && other.isAggressive()) 
            return -1;
        else {
            if (this.defense == other.getDefense()
                    || (this.attack + this.defense) == (other.getAttack() + other.getDefense())) {
                return 0;
            } else if ((this.attack + this.defense) > (other.getAttack() + other.getDefense())) {
                return 1;
            } else {
                return -1; // defensive Pokemon is considered to be "less than" another if it has a lower defense power
            }
        }
    }
}