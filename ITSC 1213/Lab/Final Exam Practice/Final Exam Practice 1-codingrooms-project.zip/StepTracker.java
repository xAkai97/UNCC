import java.util. *;

public class StepTracker {
    ArrayList<Integer> dailySteps;
    int minSteps;
    
    public StepTracker(int minSteps) {
        dailySteps = new ArrayList();
        this.minSteps = minSteps;
    }
    public void addDailySteps(int numOfSteps) {
        dailySteps.add(numOfSteps);
    }
    public int activeDays() {
        int count = 0;
        for (int steps : dailySteps) {
            if (steps > minSteps) 
                count++;
            }
        return count;
    }
 
    public double averageSteps() {
        int totalSteps = 0;
        if(dailySteps.size() == 0 ) return 0;
        for (Integer steps : dailySteps) {
            totalSteps += steps;
        }
        return ((double)totalSteps) / dailySteps.size();
    }
}