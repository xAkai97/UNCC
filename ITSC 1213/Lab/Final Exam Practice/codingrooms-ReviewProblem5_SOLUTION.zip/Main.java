import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class Main {

    public static void main(String[] args) {
        // create file to read from (input)
        File file = new File("shapeData.csv");
        // use file as input source for scanner
        Scanner scnr = null;
        try{
        scnr = new Scanner(file);
        } catch(FileNotFoundException ex){
            // exception occurred exit program
            System.out.println("Problem with input file. Program will exit.");
            System.exit(0);
        }
        // first line in input file is a header
        String header = scnr.nextLine();
        System.out.println("Header of input file: " + header);

        // read and parse data from file
        Shape shape = null;
        String line;
        String[] lineSplit;
        double area;
        while (scnr.hasNext()) { //checks if input source has more elements to read
            // read line
            line = scnr.nextLine();
            // split line using , as a value separator
            lineSplit = line.split(","); // we have an array of the individual values from the line
            // check the first value to determine which object type to create here we are
            // using equalsIgnoreCase method to handle different string cases (upper/lower)
            if (lineSplit[0].equalsIgnoreCase("cylinder")) {
                // create a Cylinder type object 
                // second element in the array (lineSplit) is the height and the third is the radius
                shape = new Cylinder(Double.parseDouble(lineSplit[1]), Double.parseDouble(lineSplit[2]));
            } else if (lineSplit[0].equalsIgnoreCase("rectangle")) {
                // create a Rectangle type object 
                // second element in the array (lineSplit) is the height and the third is the width
                shape = new Rectangle(Double.parseDouble(lineSplit[1]), Double.parseDouble(lineSplit[2]));
            }
            // calculate and print area
            area = shape.getArea();
            if (shape instanceof Rectangle) {
                System.out.print("Area of this Rectangle is ");
            } else if (shape instanceof Cylinder) {
                System.out.print("Area of this Cylinder is ");
            }
            System.out.println(shape.getArea());
        }
    }

}