public class Rectangle extends Shape {
    // fields
    private double width;
    private double height;

    // constructor
    public Rectangle(double w, double h)throws IllegalArgumentException {
        //super();  this is done implicitly if we don't include it
        if (w <= 0 || h <= 0) {
            throw new IllegalArgumentException();
        }
        width = w;
        height = h;
    }

    // method - calculates the area of this shape
    public double getArea() {
        double area = width * height;
        return area;
    }
}