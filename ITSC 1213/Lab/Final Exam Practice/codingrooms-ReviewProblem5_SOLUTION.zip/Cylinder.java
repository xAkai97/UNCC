import java.lang. *;

public class Cylinder extends Shape {
    // fields
    private double radius;
    private double height;

    // constructor
    public Cylinder(double r, double h) throws IllegalArgumentException {
        //super();  this is done implicitly if we don't include it
        if (r <= 0 || h <= 0) {
            throw new IllegalArgumentException();
        }
        radius = r;
        height = h;
    }

    // method - calculates the area of this shape
    public double getArea() {
        return ((2 * Math.PI * radius * height) + (2 * Math.PI * radius * radius));
    }
}