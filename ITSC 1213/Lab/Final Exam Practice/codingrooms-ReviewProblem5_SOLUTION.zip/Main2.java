import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

// this program is similar to Main.java but utilizes an output file to generate a report.
public class Main2 {

    public static void main(String[] args) {
        // create file to read from (input)
        File file = new File("shapeData.csv");
        // use file as input source for scanner
        Scanner scnr = null;
        try {
            scnr = new Scanner(file);
        } catch (FileNotFoundException ex) {
            // exception occurred exit program
            System.out.println("Problem with input file. Program will exit.");
            System.exit(0);
        }
        // first line in input file is a header
        String header = scnr.nextLine();
        System.out.println("Header of input file: " + header);

        // read and parse data from file
        Shape shape = null;
        String line;
        String[] lineSplit;
        double area;
        // variables to keep track of data for the report
        int numberOfRectangles = 0;
        int numberOfCylinders = 0;
        double avgRectangleArea = 0;
        double avgCylinderArea = 0;
        while (scnr.hasNext()) { //checks if input source has more elements to read
            // read line
            line = scnr.nextLine();
            // split line using , as a value separator
            lineSplit = line.split(","); // we have an array of the individual values from the line
            // check the first value to determine which object type to create here we are
            // using equalsIgnoreCase method to handle different string cases (upper/lower)
            if (lineSplit[0].equalsIgnoreCase("cylinder")) {
                // create a Cylinder type object second element in the array (lineSplit) is the
                // height and the third is the radius
                shape = new Cylinder(
                    Double.parseDouble(lineSplit[1]),
                    Double.parseDouble(lineSplit[2])
                );
                // calculate area
                area = shape.getArea();
                // update tracked values
                numberOfCylinders++;
                avgCylinderArea = avgCylinderArea + area; // running total of the areas for now


            } else if (lineSplit[0].equalsIgnoreCase("rectangle")) {
                // create a Rectangle type object second element in the array (lineSplit) is the
                // height and the third is the width
                shape = new Rectangle(
                    Double.parseDouble(lineSplit[1]),
                    Double.parseDouble(lineSplit[2])
                );
                // calculate area
                area = shape.getArea();
                // update tracked values
                numberOfRectangles++;
                avgRectangleArea = avgRectangleArea + area; // running total of the areas for now
            }
        }

        // create report file

        PrintWriter printer = null;
        try {
            printer = new PrintWriter("outputReport.txt");
        } catch (FileNotFoundException ex) {
            // exception occurred exit program
             System.out.println("Problem with output file. Program will exit.");
            System.exit(0);
        }
        printer.println("Summary of shapes and areas ");
        printer.println("*****************************");
        printer.println("In the data file we have found " + numberOfCylinders + 
            " Cylinder shapes and their measurements.");
        printer.println("The average calculated area of those Cylinders was " + 
            (avgCylinderArea / numberOfCylinders));
        printer.println("*****************************");

        printer.println("In the data file we have found " + numberOfRectangles + 
            " Rectangle shapes and their measurements.");
        printer.println("The average calculated area of those Rectangles was " + 
            (avgRectangleArea / numberOfRectangles));
        printer.println("*****************************");
        //close printer object
        printer.close();

    }

}