class Cat extends Animal
{
  public Cat(int age, double weight, String name)
  {
      super(age,weight,name);
  }  
  public String getVoiceName()
  {
      return "Meow";
  }
}