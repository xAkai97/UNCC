class Dog extends Animal
{
  public Dog(int age, double weight, String name)
  {
      super(age,weight,name);
  }  
  public String getVoiceName()
  {
      return "Bark";
  }
}