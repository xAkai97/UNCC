abstract class Animal
{
    private int age;
    private double weight;
    private String name;
    public Animal(int age, double weight, String name)
    {
        this.age = age;
        this.weight = weight;
        this.name = name;

    }
    public int getAge()
    {
        return age;
    }
    public void setAge(int age)
    {
        if(age <= 0)
            throw new IllegalArgumentException("Age less than 0");
        this.age = age;
    }
    public String getName()
    {
        return name;
    }
    public void setName(String s)
    {
        this.name = s;
    }
    public double getWeight()
    {
        return weight;
    }
    public void setWeight(double weight)
    {
        this.weight = weight;
    }
    abstract public String getVoiceName();
}