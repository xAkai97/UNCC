import java.util.*;
import java.io.*;
public class Main {

    public static void main(String[] args) {
        Scanner scanner = null;
        try {
             File file = new File("animalData.csv");
             scanner = new Scanner(file);

             scanner.nextLine(); // to skip the header (first line in the file)
             while(scanner.hasNextLine())
             {
                 String [] line = scanner.nextLine().split(",");
                 int age = Integer.parseInt(line[3]);// age in the file is the 4th column
                 double weight = Double.parseDouble(line[2]); // weight is the 3rd column
                 String name = line[1]; // name the 2nd column
                 if(line[0].equals("cat"))
                 {
                    Cat cat = new Cat(age,weight,name);
                    System.out.println(cat.getName()+ ", "+ cat.getAge()+", "+cat.getWeight()+", "+cat.getVoiceName());
                 }
                 else if(line[0].equals("dog"))
                 {
                    Dog dog = new Dog(age,weight,name);
                    System.out.println(dog.getName()+ ", "+ dog.getAge()+", "+dog.getWeight()+", "+dog.getVoiceName());
                 }
             }
            
        }
        catch(FileNotFoundException exp)
        {
            System.out.println("File Not Found "+exp);
        }
        finally {
            if(scanner != null)
                scanner.close();
        }
       

    }

}
