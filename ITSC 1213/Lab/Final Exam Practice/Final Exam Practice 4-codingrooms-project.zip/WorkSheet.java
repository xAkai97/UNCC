import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author Derek
 */
public class WorkSheet {

    private int[][] yearWorkHours = new int[12][30];

    Scanner sc;
    File sheet;

    public WorkSheet() throws FileNotFoundException {
        sheet = new File("worksheetData.csv");
        sc = new Scanner(sheet);
    }

    public boolean populateWorkSheet() {
        boolean val = false;
        int l;
        for (int i = 0; i < yearWorkHours.length; i++) {
            String[] stHr = sc.nextLine().split(" ,");
            int[] inHr = new int[30];
            for (int j = 0; j < stHr.length; j++) {
                l = Integer.parseInt(stHr[j]);
                inHr[j] = l;
            }
            yearWorkHours[i] = inHr;// for  collumns  every element for(int j; j < yearsWorkHours[0].length; j++) yearsWorkHours[i][j] = inHr[j];

        }
        if (yearWorkHours != null) {
            val = true;
        }
        return val;
    }

    public int[][] getYearWorkHours() {
        return yearWorkHours;
    }

    public int getMonthTotalHours(int month) throws InvalidInputException {
        int total = 0;
        month = month - 1; // if user was to enter 1 would make it 0 acessing Jan enters a 12 turns to 11 acessing Dec

        if (month < 0) {
            throw new InvalidInputException();
        } else if (month >= 12) {
            throw new InvalidInputException();
        }

        for (int j = 0; j < 30; j++) {
            total = total + yearWorkHours[month][j];
        }

        return total;

    }

    public double getAvgDailyHours(int month) throws InvalidInputException {
        month = month - 1; // if user was to enter 1 would make it 0 acessing Jan enters a 12 turns to 11 acessing Dec
        if (month < 0) {
            throw new InvalidInputException();
        } else if (month >= 12) {
            throw new InvalidInputException();
        }
        double total = 0;
        for (int j = 0; j < 30; j++) {
            total = total + yearWorkHours[month][j];
        }
        total = (total / 30.0);
        String format = String.format("%.2f", total);
        double total1 = Double.parseDouble(format);
        return total1;
    }

    public int getLowestWorkingDay(int month) throws InvalidInputException {
        month = month - 1; // if user was to enter 1 would make it 0 acessing Jan enters a 12 turns to 11 acessing Dec
        if (month < 0) {
            throw new InvalidInputException();
        } else if (month >= 12) {
            throw new InvalidInputException();
        }
        int min = 12;
        for (int j = 0; j < 30; j++) {
            if (yearWorkHours[month][j] < min) {
                min = yearWorkHours[month][j];
            }
        }
        return min;
    }

    public int getHeighestWorkingDay(int month) throws InvalidInputException {
        month = month - 1; // if user was to enter 1 would make it 0 acessing Jan enters a 12 turns to 11 acessing Dec
        if (month < 0) {
            throw new InvalidInputException();
        } else if (month >= 12) {
            throw new InvalidInputException();
        }
        int min = 0;
        for (int j = 0; j < 30; j++) {
            if (yearWorkHours[month][j] > min) {
                min = yearWorkHours[month][j];
            }
        }
        return min;
    }

    public static class InvalidInputException extends Exception {

        public InvalidInputException() {

        }
    }
}