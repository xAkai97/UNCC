import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Derek
 */
public class Main {

    public static void main(String[] args) throws FileNotFoundException, IOException {
        WorkSheet sheet = new WorkSheet();
        sheet.populateWorkSheet();

        System.out.println("");
        System.out.println("Jan Stats");
        System.out.println("=========");

        try {
            System.out.println("Total hours worked for Jan: " + sheet.getMonthTotalHours(1));
        } catch (WorkSheet.InvalidInputException ex) {
            System.out.println("Enter a number between 1-12 for totalMonth");
        }

        try {
            System.out.println("Avg hours worked for Jan: " + sheet.getAvgDailyHours(1));
        } catch (WorkSheet.InvalidInputException ex) {
            System.out.println("Enter a number between 1-12 for Avg");
        }

        try {
            System.out.println("Lowest hours worked for Jan: " + sheet.getLowestWorkingDay(1));
        } catch (WorkSheet.InvalidInputException ex) {
            System.out.println("Enter a number between 1-12 for lowestWork");
        }

        try {
            System.out.println("Highest hours worked for Jan: " + sheet.getHeighestWorkingDay(1));
        } catch (WorkSheet.InvalidInputException ex) {
            System.out.println("Enter a number between 1-12 for Highest");
        }

        System.out.println("");
        System.out.println("Simple Unit Testing");
//Unit tests for totHrs
        System.out.println("Testing totalHours method");
        int result;
        try {
            result = sheet.getMonthTotalHours(12);
            System.out.println("Test 1 totalHours: " + validate(262, result));
        } catch (WorkSheet.InvalidInputException ex) {
            System.out.println("Enter a number between 1-12");
        }

        try {
            result = sheet.getMonthTotalHours(3);
            System.out.println("Test 2 totalHours: " + validate(264, result));
        } catch (WorkSheet.InvalidInputException ex) {
            System.out.println("Enter a number between 1-12");
        }

        try {
            result = sheet.getMonthTotalHours(9);
            System.out.println("Test 3 totalHours: " + validate(281, result));
        } catch (WorkSheet.InvalidInputException ex) {
            System.out.println("Enter a number between 1-12");
        }

        try {
            result = sheet.getMonthTotalHours(5);
            System.out.println("Test 4 totalHours: " + validate(278, result));
        } catch (WorkSheet.InvalidInputException ex) {
            System.out.println("Enter a number between 1-12");
        }
        System.out.println("--------------------------------");
//Unit tests for Avg
        System.out.println("Testing Avg method");
        double result1;
        try {
            result1 = sheet.getAvgDailyHours(12);
            System.out.println("Test 1 Avg: " + validate(8.73, result1));
        } catch (WorkSheet.InvalidInputException ex) {
            System.out.println("Enter a number between 1-12");
        }

        try {
            result1 = sheet.getAvgDailyHours(3);
            System.out.println("Test 2 Avg: " + validate(8.80, result1));
        } catch (WorkSheet.InvalidInputException ex) {
            System.out.println("Enter a number between 1-12");
        }

        try {
            result1 = sheet.getAvgDailyHours(9);
            System.out.println("Test 3 Avg: " + validate(9.37, result1));
        } catch (WorkSheet.InvalidInputException ex) {
            System.out.println("Enter a number between 1-12");
        }

        try {
            result1 = sheet.getAvgDailyHours(5);
            System.out.println("Test 4 Avg: " + validate(9.27, result1));
        } catch (WorkSheet.InvalidInputException ex) {
            System.out.println("Enter a number between 1-12");
        }
        System.out.println("--------------------------------");
        //Unit tests for low
        System.out.println("Testing Low method");
        try {
            result = sheet.getLowestWorkingDay(12);
            System.out.println("Test 1 low: " + validate(6, result));
        } catch (WorkSheet.InvalidInputException ex) {
            System.out.println("Enter a number between 1-12");
        }

        try {
            result = sheet.getLowestWorkingDay(3);
            System.out.println("Test 2 low: " + validate(6, result));
        } catch (WorkSheet.InvalidInputException ex) {
            System.out.println("Enter a number between 1-12");
        }

        try {
            result = sheet.getLowestWorkingDay(9);
            System.out.println("Test 3 low: " + validate(6, result));
        } catch (WorkSheet.InvalidInputException ex) {
            System.out.println("Enter a number between 1-12");
        }

        try {
            result = sheet.getLowestWorkingDay(5);
            System.out.println("Test 4 low: " + validate(6, result));
        } catch (WorkSheet.InvalidInputException ex) {
            System.out.println("Enter a number between 1-12");
        }

        System.out.println("--------------------------------");
        //Unit tests for high 
        System.out.println("Testing High method");
        try {
            result = sheet.getHeighestWorkingDay(12);
            System.out.println("Test 1 high: " + validate(12, result));
        } catch (WorkSheet.InvalidInputException ex) {
            System.out.println("Enter a number between 1-12");
        }

        try {
            result = sheet.getHeighestWorkingDay(3);
            System.out.println("Test 2 high: " + validate(12, result));
        } catch (WorkSheet.InvalidInputException ex) {
            System.out.println("Enter a number between 1-12");
        }

        try {
            result = sheet.getHeighestWorkingDay(9);
            System.out.println("Test 3 high: " + validate(12, result));
        } catch (WorkSheet.InvalidInputException ex) {
            System.out.println("Enter a number between 1-12");
        }

        try {
            result = sheet.getHeighestWorkingDay(5);
            System.out.println("Test 4 high: " + validate(12, result));
        } catch (WorkSheet.InvalidInputException ex) {
            System.out.println("Enter a number between 1-12");
        }

        //File writing 
        FileOutputStream fs;
        fs = new FileOutputStream("t.txt");

        PrintWriter outFS = new PrintWriter(fs);
        outFS.println("Month" + " | " + "TotHrs" + " | " + "TotPay" + " | " + "AvgHrs" + " | " + "HighWorkHrs" + " | " + "LowWorkHrs" + " | ");
        for (int i = 1; i < 13; i++) {
            try {
                outFS.println(i + " | " + sheet.getMonthTotalHours(i) + " | " + sheet.getMonthTotalHours(i) * 20
                        + " | " + sheet.getAvgDailyHours(i) + " | " + sheet.getHeighestWorkingDay(i) + " | " + sheet.getLowestWorkingDay(i));
            } catch (WorkSheet.InvalidInputException ex) {
                System.out.println("Enter a number between 1-12");
            }
        }

        outFS.close();
        fs.close();
    }

    private static String validate(int expected, int result) {
        if (result != expected) {
            return ("The result " + result + " does not match expected: " + expected + " --->> Failed");
        } else {
            return ("The result " + result + " match expected: " + expected + " --->> OK");
        }
    }

    private static String validate(double expected, double result) {
        if (result != expected) {
            return ("The result " + result + " does not match expected: " + expected + " --->> Failed");
        } else {
            return ("The result " + result + " match expected: " + expected + " --->> OK");
        }
    }

}
