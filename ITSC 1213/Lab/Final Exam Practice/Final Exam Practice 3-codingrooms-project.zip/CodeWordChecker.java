public class CodeWordChecker implements StringChecker {
    private String badString;
    private int minLength = 6;
    private int maxLength = 20;

    CodeWordChecker(String badString) {
        this.badString = badString;
    }

    CodeWordChecker(int min, int max, String badString) {
        this.badString = badString;
        this.minLength = min;
        this.maxLength = max;

    }

    public boolean isValid(String codeWord) {
        if (codeWord.length() < minLength || codeWord.length() > maxLength) {
            return false;
        }
        if (codeWord.contains(this.badString)) {
            return false;
        } else {
            return true;
        }
    }

}