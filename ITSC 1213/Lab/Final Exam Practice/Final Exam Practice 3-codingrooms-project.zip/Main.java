public class Main {

    public static void main(String[] args) {

        System.out.println("Example 1:");
        StringChecker sc1 = new CodeWordChecker(5, 8, "$");
        System.out.println(sc1.isValid("happy"));
        System.out.println(sc1.isValid("$$$$$"));
        System.out.println(sc1.isValid("code"));
        System.out.println(sc1.isValid("happyCode"));

        System.out.println("Example 2:");
        StringChecker sc2 = new CodeWordChecker("pass");
        System.out.println(sc2.isValid("MyPass"));
        System.out.println(sc2.isValid("mypassword"));
        System.out.println(sc2.isValid("happy"));
        System.out.println(sc2.isValid("1,000,000,000,000,000"));

    }

}
