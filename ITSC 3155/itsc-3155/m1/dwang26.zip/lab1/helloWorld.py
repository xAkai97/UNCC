def greet():
    # TODO 1: Finish this function's implementation
    # - print "Hello, World!" to the console
    print ("Hello, World!")


def main():
    greet()


if __name__ == '__main__':
    main()
